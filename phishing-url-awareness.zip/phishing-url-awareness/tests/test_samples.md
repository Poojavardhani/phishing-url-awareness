# Test Results

Python version used: [fill in after running]  |  Operating system: [fill in]  |  Date: [fill in]

| # | Input | Expected result | Actual result | Pass/Fail |
|---|---|---|---|---|
| 1 | `https://www.example.com/login` | No listed warning signs; not a safety guarantee | [record actual output] | [PASS/FAIL] |
| 2 | `http://192.0.2.10/account` | IP address + HTTP | [record actual output] | [PASS/FAIL] |
| 3 | `http://example.com@sample.invalid/login` | @ symbol + HTTP | [record actual output] | [PASS/FAIL] |
| 4 | `https://a.b.c.d.e.example.invalid/path` | Many hostname segments | [record actual output] | [PASS/FAIL] |
| 5 | `https://xn--example.invalid/` | Punycode-style hostname | [record actual output] | [PASS/FAIL] |

## Notes
- [Write what you learned from the tests.]
- [Write anything that surprised you.]

## Optional bonus checks
- Empty input should display `No URL entered.`
- `www.example.com` is treated as HTTP because a missing scheme is prefixed with `http://`.
- `https://secure-login.example.invalid` can show no listed warning signs; this demonstrates that the tool cannot prove safety.
- `http://[bad` should return a friendly malformed-format message rather than crash.
